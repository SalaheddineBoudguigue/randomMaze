package tile;

public class Obstacle{

	public int m_x, m_y;
	public int m_width = 48;
	public int m_height = 48;
	
	public Obstacle(int x, int y){
		m_x = x;
		m_y = y;
	}
	
}
